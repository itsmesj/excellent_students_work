import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Login from "./login";
import Signup from "./signup";
import Dashboard from "./dashboard";
import "./index.css";

export default function App() {
  const [auth, setAuth] = useState(false);

  // refresh hone ke baad bhi login rahe
  useEffect(() => {
    const isAuth = localStorage.getItem("isAuth");
    if (isAuth === "true") {
      setAuth(true);
    }
  }, []);

  return (
    <Router>
      <Routes>
        {!auth ? (
          <>
            <Route path="/" element={<Login setAuth={setAuth} />} />
            <Route path="/login" element={<Login setAuth={setAuth} />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="*" element={<Navigate to="/login" />} />
          </>
        ) : (
          <>
            <Route path="/dashboard" element={<Dashboard setAuth={setAuth} />} />
            <Route path="*" element={<Navigate to="/dashboard" />} />
          </>
        )}
      </Routes>
    </Router>
  );
}

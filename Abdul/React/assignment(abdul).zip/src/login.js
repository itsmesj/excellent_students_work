import React from "react";
import { Link, useNavigate } from "react-router-dom";
import "./index.css";

export default function Login({ setAuth }) {
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    const email = e.target.email.value;
    const password = e.target.password.value;


    const storedUser = JSON.parse(localStorage.getItem("user"));

    if (storedUser && storedUser.email === email && storedUser.password === password) {
      localStorage.setItem("isAuth", "true");
      setAuth(true);
      navigate("/dashboard");
    } else {
      alert("Invalid credentials or please signup first!");
    }
  };

  return (
    <div className="form-container">
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <input type="email" name="email" placeholder="Email" required />
        <input type="password" name="password" placeholder="Password" required />
        <button type="submit">Login</button>
      </form>
      <p>
        <span>Don’t have an account?</span> <Link to="/signup">Signup</Link>
      </p>
    </div>
  );
}

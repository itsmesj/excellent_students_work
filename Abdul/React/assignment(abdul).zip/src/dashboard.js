import React from "react";
import { useNavigate } from "react-router-dom";
import "./index.css";

export default function Dashboard({ setAuth }) {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const logout = () => {
    localStorage.removeItem("isAuth");
    setAuth(false);
    navigate("/login");
  };

  return (
    
    <div className="dashboard">
     
      <nav className="navbar">
        <div className="logo">ShopEasy</div>
        <ul className="nav-links">
          <li>Home</li>
          <li>Products</li>
          <li>About</li>
          <li>Contact</li>
        </ul>
        <button className="logout-btn" onClick={logout}>
          Logout
        </button>
      </nav>

    
      <header className="hero">
        <h1>Welcome, {user?.name} 🎉</h1>
        <p>Your one-stop shop for everything!</p>
      </header>

     
      <section className="products">
        <div className="product-card">
          <img src="https://redtape.com/cdn/shop/files/RSO4034_1_40cd841c-11dc-4c78-ab85-bfad034e31fe.jpg?v=1755860331" alt="Product 1" />
          <h3>Stylish Shoes</h3>
          <p>$40</p>
          <button>Add to Cart</button>
        </div>

        <div className="product-card">
          <img src="https://m.media-amazon.com/images/I/71syP5d3+SL._SY741_.jpg" alt="Product 2" />
          <h3>Trendy Watch</h3>
          <p>$60</p>
          <button>Add to Cart</button>
        </div>

        <div className="product-card">
          <img src="https://m.media-amazon.com/images/I/31Q14qzdoZL._SX300_SY300_QL70_FMwebp_.jpg" alt="Product 3" />
          <h3>Smartphone</h3>
          <p>$250</p>
          <button>Add to Cart</button>
        </div>

        <div className="product-card">
          <img src="https://m.media-amazon.com/images/I/31ztpzzaDSL._SX300_SY300_QL70_FMwebp_.jpg" alt="Product 4" />
          <h3>Headphones</h3>
          <p>$80</p>
          <button>Add to Cart</button>
        </div>
      </section>

      
      {/* <footer className="footer">
        <p>© 2025 ShopEasy. All rights reserved.</p>
      </footer> */}
    </div>
  );
}

import React from "react";
import { Link, useNavigate } from "react-router-dom";
import "./index.css";  

export default function Signup() {
  const navigate = useNavigate();

  const handleSignup = (e) => {
    e.preventDefault();
    const name = e.target.name.value;
    const email = e.target.email.value;
    const password = e.target.password.value;

    
    localStorage.setItem("user", JSON.stringify({ name, email, password }));

    alert("Signup successful! Now login.");
    navigate("/login");
  };

  return (
    <div className="form-container">
      <h2>Signup</h2>
      <form onSubmit={handleSignup}>
        <input type="text" name="name" placeholder="Name" required />
        <input type="email" name="email" placeholder="Email" required />
        <input type="password" name="password" placeholder="Password" required />
        <button type="submit">Signup</button>
      </form>
      <p>
        <span>Already have an account?</span> <Link to="/login">Login</Link>
      </p>
    </div>
  );
}

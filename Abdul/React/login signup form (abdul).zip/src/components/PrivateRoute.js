import { useNavigate, Outlet } from "react-router-dom"

export default function PrivateRoute({isAuthenticated}) {
    const navigate = useNavigate();
    return (
        isAuthenticated ? <Outlet /> : navigate('/login', { replace: true } )
    );
}
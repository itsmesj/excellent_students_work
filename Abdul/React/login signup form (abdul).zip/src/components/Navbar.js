import { Link } from "react-router-dom";
export default function Navbar({ isAuthenticated, onLogout }) {
    return (
        <nav style={styles.nav}>
            <h2 style={{color: "#333"}}>React Auth</h2>
            <div>
                <Link style={styles.link} to="/">Home</Link>
                {isAuthenticated ? (
                    <>
                        <Link style={styles.link} to="/dashboard">Dashboard</Link>
                        <Link style={styles.link} to="/profile">Profile</Link>
                        <button style={styles.btn} onClick={onLogout}>Logout</button>
                    </>
                ) : (
                    <>
                        <Link style={styles.link} to="/login">Login</Link>
                        <Link style={styles.link} to="/signup">Signup</Link>
                    </>
                )
                }

            </div>
        </nav>
    );
}


const styles = {
  nav: { padding: "10px 20px", background: "#f4f4f4", display: "flex", justifyContent: "space-between" },
  link: { margin: "0 10px", textDecoration: "none", color: "#0077cc", fontWeight: "500" },
  btn: { marginLeft: "10px", background: "#ff5c5c", color: "#fff", border: "none", padding: "5px 10px", cursor: "pointer" }
};

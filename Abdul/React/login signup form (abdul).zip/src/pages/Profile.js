import { use } from "react"

export default function Profile() {
    const user = JSON.parse(localStorage.getItem('user'));
    return (
        <div style={{ textAlign: 'center' }}>
            <h1>Profile Page</h1>
            { user?(
                <>
                <h2>{user.name}</h2>
                <p>Email: {user.email}</p>
                <p>Welcome to your profile! Here you can view and edit your personal information.</p>
                </>
            ):(
                <p>No user data found</p>
            )
            }
        </div>
    );
}
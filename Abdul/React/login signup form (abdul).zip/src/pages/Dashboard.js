import { Link } from "react-router-dom";
export default function Dashboard(){
    return (
        <div style={{ textAlign: 'center' }}>
            <h1>Dashboard</h1>
            <p>Welcome to your dashboard! Here you can manage your account settings and view your profile information.</p>
            <div style={styles.cards}>
                <div style={styles.card}>
                    <h3>Profile</h3>
                    <p style={styles.text}>View your account details</p>
                    <Link style={styles.link} to="/profile">Go to Profile</Link>
                </div>
                <div style={styles.card}>
                    <h3>Settings</h3>
                    <p style={styles.text}>Manage your account settings</p>
                    <button style={styles.btn}>Open Settings</button>
                </div>
                <div style={styles.card}>
                    <h3>Support</h3>
                    <p style={styles.text}>Need help? Contact our support team</p>
                    <button style={styles.btn}>Contact Support</button>
                </div>
            </div>
        </div>
    );
}


const styles = {
  cards: { display: "flex", justifyContent: "center", gap: "20px", marginTop: "20px" },
  card: { border: "1px solid #ddd", borderRadius: "8px", padding: "15px", width: "200px", background: "#fafafa"},
    btn: { padding: "10px", background: "#0077cc", color: "#fff", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold"
   },text: { fontSize: "14px" },
   link: { color: "#0077cc", textDecoration: "none" },
};

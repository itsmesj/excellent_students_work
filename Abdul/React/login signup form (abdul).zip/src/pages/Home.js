export default function Home(){
    return(
        <div style={{ textAlign: 'center', marginTop: '50px' }}>
            <h1>Welcome to the React Auth App🚀</h1>
            <p>This is the home page of our application. This application is built using React + React-router-dom + Local Storage.</p>
        </div>
    );
}
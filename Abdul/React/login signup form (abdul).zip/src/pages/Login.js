import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
export default function Login({ onLogin }) {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();
    const handleLogin = (e) => {
        e.preventDefault();
        const savedUser = JSON.parse(localStorage.getItem('user'));
        if (savedUser && savedUser.email === email && savedUser.password === password) {
            onLogin();
            navigate("/dashboard");
        }
        else {
            alert('Invalid credentials');
        }
    }
    return (
        <div style={styles.container}>
            <form style={styles.card}>
                <h2 style={styles.heading}>Login</h2>
                <input
                    style={styles.input}
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <input
                    style={styles.input}
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <button style={styles.btn} type="submit" onClick={handleLogin}>Login</button>
                <p style={styles.text}>Don't have an account?
                    <Link to="/signup" style={styles.link}>Signup</Link>
                </p>
            </form>
        </div>
    );
}


const styles = {
    container: { display: "flex", justifyContent: "center", alignItems: "center", height: "80vh" },
    card: {
        display: "flex", flexDirection: "column", gap: "15px",
        width: "350px", padding: "30px",
        borderRadius: "12px", background: "#fff",
        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
        textAlign: "center"
    },
    heading: { marginBottom: "10px", color: "#333" },
    input: { padding: "10px", borderRadius: "6px", border: "1px solid #ccc", fontSize: "14px" },
    btn: { padding: "10px", background: "#0077cc", color: "#fff", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold" },
    text: { fontSize: "14px" },
    link: { color: "#0077cc", textDecoration: "none" }
};

import React from "react";
import { useNavigate } from "react-router-dom";
import "./dashboard.css";

export default function Dashboard({ setAuth }) {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const logout = () => {
    localStorage.removeItem("isAuth");
    setAuth(false);
    navigate("/login");
  };

  return (
    <div className="dashboard">
      
      <nav className="navbar">
        <div className="logo">ShopEasy</div>

        <input
          type="text"
          placeholder="Search products..."
          className="search-bar"
        />

        <ul className="nav-links">
          <li>Home</li>
          <li>Products</li>
          <li>About</li>
          <li>Contact</li>
        </ul>

        <div className="cart">
          🛒 <span className="cart-count">0</span>
        </div>

        <button className="logout-btn" onClick={logout}>
          Logout
        </button>
      </nav>
<main>
    
      <header className="hero">
        <h1>Welcome, {user?.name} 🎉</h1>
        <p>Your one-stop shop for everything!</p>
        <button
          className="shop-btn"
          onClick={() =>
            window.scrollTo({ top: 600, behavior: "smooth" })
          }
        >
          Shop Now
        </button>
      </header>

    
      <section className="products">
        <div className="product-card">
          <span className="badge">Sale</span>
          <img src="https://redtape.com/cdn/shop/files/RSO4034_1_40cd841c-11dc-4c78-ab85-bfad034e31fe.jpg?v=1755860331" alt="Product 1" />
          <h3>Stylish Shoes</h3>
          <p>$40</p>
          <div className="stars">⭐⭐⭐⭐☆</div>
          <button>Add to Cart</button>
          <button className="wishlist">❤️ Wishlist</button>
        </div>

        <div className="product-card">
          <img src="https://m.media-amazon.com/images/I/71syP5d3+SL._SY741_.jpg" alt="Product 2" />
          <h3>Trendy Watch</h3>
          <p>$60</p>
          <div className="stars">⭐⭐⭐⭐⭐</div>
          <button>Add to Cart</button>
          <button className="wishlist">❤️ Wishlist</button>
        </div>

        <div className="product-card">
          <img src="https://m.media-amazon.com/images/I/31Q14qzdoZL._SX300_SY300_QL70_FMwebp_.jpg" alt="Product 3" />
          <h3>Smartphone</h3>
          <p>$250</p>
          <div className="stars">⭐⭐⭐⭐☆</div>
          <button>Add to Cart</button>
          <button className="wishlist">❤️ Wishlist</button>
        </div>

        <div className="product-card">
          <img src="https://m.media-amazon.com/images/I/31ztpzzaDSL._SX300_SY300_QL70_FMwebp_.jpg" alt="Product 4" />
          <h3>Headphones</h3>
          <p>$80</p>
          <div className="stars">⭐⭐⭐☆☆</div>
          <button>Add to Cart</button>
          <button className="wishlist">❤️ Wishlist</button>
        </div>
      </section>

    
      <section className="offers">
        <h2>🔥 Special Offers</h2>
        <div className="offer-cards">
          <div className="offer-card">50% OFF on Shoes 👟</div>
          <div className="offer-card">Buy 1 Get 1 Free 🎁</div>
          <div className="offer-card">Smartphone Sale 📱</div>
        </div>
      </section>

     
      <section className="testimonials">
        <h2>💬 What Our Customers Say</h2>
        <div className="testimonial-cards">
          <div className="testimonial">
            <p>"Great quality and fast delivery!"</p>
            <h4>- Rahul</h4>
          </div>
          <div className="testimonial">
            <p>"Best shopping experience ever!"</p>
            <h4>- Ayesha</h4>
          </div>
          <div className="testimonial">
            <p>"Amazing discounts and offers."</p>
            <h4>- Vikram</h4>
          </div>
        </div>
      </section>

      
      <section className="services">
        <div className="service">🚚 Free Shipping</div>
        <div className="service">🔒 Secure Payment</div>
        <div className="service">🔄 Easy Returns</div>
        <div className="service">☎️ 24/7 Support</div>
      </section>
      </main>

      
      <footer className="footer">
        <p>© 2025 ShopEasy. All rights reserved.</p>
        <div className="socials">
          <span>🌐 Facebook</span>
          <span>🐦 Twitter</span>
          <span>📸 Instagram</span>
        </div>
      </footer>
    </div>
  );
}

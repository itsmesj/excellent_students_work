import './App.css';
import { useState } from 'react';
function App() {

  const [count, setCount] = useState(0);
  return (
    <>
    <div className='App-header'>

    <p>{count}</p>

      <div className='buttons'>
      <button onClick={()=>setCount(count+1)}>plus+</button>
      <button onClick={()=>setCount(count-1)}>minus-</button>
      <button onClick={()=>setCount(count*count)}>square root</button>
      <button onClick={()=>setCount(count*10)}>multiply 10x</button>
      <button onClick={()=>setCount(count + count)}>double</button>
      <button onClick={()=>setCount(0)}>clear</button>
      </div>
    </div>
    </>
  );
}

export default App;

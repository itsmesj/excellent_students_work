import React from "react";
import "./Component1.scss";

const Component1 = () => {
  return (
    <div className="App">
      <nav className="navbar">
        <div className="logo">
            <span className="logo-icon"></span> Musico.
        </div>

        <ul className="nav-links">
          <li>Home</li>
          <li>About</li>
          <li>Tracks</li>

          <li className="dropdown">
            Blog
            <ul className="dropdown-menu">
              <li>Blog Grid</li>
              <li>Blog Details</li>
            </ul>
          </li>

          <li className="dropdown">
            Pages
            <ul className="dropdown-menu">
              <li>Service</li>
              <li>Gallery</li>
            </ul>
          </li>
          <li>Contact</li>
        </ul>
      </nav>
      



      <div className="hero">
        <img
          src="https://preview.colorlib.com/theme/musico/img/banner/banner.png.webp"
          alt="sample"
          className="hero-img"
        />
      </div>

      <div className="hero-text">
        <h1>MUSICIAN</h1>
       
      </div>
    </div>
  );
};

export default Component1;

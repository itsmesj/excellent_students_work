import Component1 from "./Component1";

export default function App() {
  return(
    <div>
      {/* <h2>welcome to my app new</h2> */}
      

      <Component1 />
    </div>
  );
};